import test, { expect } from '@playwright/test'
import { LoginPage } from '../pages/LoginPage'
import { HomePage } from '../pages/HomePage'
import { CreateLeadPage } from '../pages/CreateLeadPage'
import { faker } from '@faker-js/faker'

// Test: Create a Lead using Page Object Model and Faker for test data
test('Create Lead - LeaFTaps POM', async ({ page }) => {
  // Instantiate page objects
  const login = new LoginPage(page)
  const home = new HomePage(page)
  const createLead = new CreateLeadPage(page)

  // 1) Navigate to login page
  await login.goto()

  // 2) Perform login with provided credentials
  // Data credentials: username = DemoSalesManager, password = crmsfa
  await login.login('DemoSalesManager', 'crmsfa')

  // 3) Navigate to Leads > Create Lead
  await home.clickLeads()
  await home.clickCreateLead()

  // 4) Generate test data using Faker
  const company = faker.company.name()
  const firstName = faker.person.firstName()
  const lastName = faker.person.lastName()
  const email = faker.internet.email({ firstName, lastName })
  const phone = faker.phone.number()

  // 5) Fill the Create Lead form and submit
  await createLead.createLead(company, firstName, lastName, email, phone)

  // 6) Assert that the lead was created by checking page content
  // The view lead page typically contains the lead's first and last name
  await expect(page).toHaveURL(/.*viewLead.*/)
  await expect(page.locator('#viewLead_firstName_sp')).toContainText(firstName)
  await expect(page.locator('#viewLead_lastName_sp')).toContainText(lastName)
})
