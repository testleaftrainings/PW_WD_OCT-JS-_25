import test, { expect } from '@playwright/test'
import { LoginPage } from '../pages/LoginPage'
import { HomePage } from '../pages/HomePage'
import { CreateAccountPage } from '../pages/CreateAccountPage'
import { faker } from '@faker-js/faker'

// Test: Create an Account using Page Object Model and Faker for test data
test('Create Account - LeaFTaps POM', async ({ page }) => {
  // Instantiate page objects
  const login = new LoginPage(page)
  const home = new HomePage(page)
  const createAccount = new CreateAccountPage(page)

  // 1) Navigate to login page
  await login.goto()

  // 2) Perform login with provided credentials
  // Data credentials: username = DemoSalesManager, password = crmsfa
  await login.login('DemoSalesManager', 'crmsfa')

  // 3) Navigate to Accounts > Create Account
  await home.clickAccounts()
  await home.clickCreateAccount()

  // 4) Generate test data using Faker
  const accountName = faker.company.name()

  // 5) Fill the Create Account form and submit
  await createAccount.createAccount(accountName)

  // 6) Assert that the account name appears on the resulting page
  const pageText = await createAccount.getAccountText()
  await expect(pageText).toContain(accountName)
})
