import { Page } from '@playwright/test'

// Page Object Model for the Login page of LeaFTaps
export class LoginPage {
  constructor(private page: Page) {}

  // Navigate to the LeaFTaps login page
  async goto() {
    await this.page.goto('http://leaftaps.com/opentaps/control/main')
  }

  // Fill credentials and perform login, then click CRM/SFA to enter the app
  async login(username: string, password: string) {
    // Fill username
    await this.page.fill('#username', username)
    // Fill password
    await this.page.fill('#password', password)
    // Click the login button and wait for the post-login navigation to complete
    await Promise.all([
      this.page.waitForNavigation({ waitUntil: 'domcontentloaded' }),
      this.page.click('.decorativeSubmit'),
    ])

    // Wait for the CRM/SFA link to be visible on the landing page, then click it
    await this.page.waitForSelector("text=CRM/SFA", { timeout: 5000 })
    await this.page.click("text=CRM/SFA")
  }
}
