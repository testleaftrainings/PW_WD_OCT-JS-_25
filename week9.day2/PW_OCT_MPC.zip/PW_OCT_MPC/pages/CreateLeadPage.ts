import { Page } from '@playwright/test'

// Page Object Model for the Create Lead page
export class CreateLeadPage {
  constructor(private page: Page) {}

  // Fill the create lead form and submit
  async createLead(company: string, firstName: string, lastName: string, email: string, phone: string) {
    // Fill company name
    await this.page.fill('#createLeadForm_companyName', company)
    // Fill first name
    await this.page.fill('#createLeadForm_firstName', firstName)
    // Fill last name
    await this.page.fill('#createLeadForm_lastName', lastName)
    // Fill primary email
    await this.page.fill('#createLeadForm_primaryEmail', email)
    // Fill primary phone number
    await this.page.fill('#createLeadForm_primaryPhoneNumber', phone)
    // Click the Create/Submit button
    await this.page.click('input[name="submitButton"]')
  }

  // Helper: return the page text that typically contains the created lead's name
  async getCreatedLeadText() {
    return this.page.textContent('#sectionHeaderTitle_leads') || ''
  }
}
