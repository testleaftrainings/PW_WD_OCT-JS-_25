import { Page } from '@playwright/test'

// Page Object Model for the Create Account page in LeaFTaps
export class CreateAccountPage {
  constructor(private page: Page) {}

  // Fill minimal account data and submit. We keep fields minimal to reduce flakiness.
  async createAccount(accountName: string) {
    // Fill the Account Name field
    await this.page.fill('#accountName', accountName)

    // Click the Create/Submit button (shared name with other forms)
    await this.page.click('input[name="submitButton"]')
  }

  // Get visible text that likely contains the created account name
  async getAccountText() {
    // Return the whole page text so test can assert account name presence
    return this.page.textContent('body') || ''
  }
}
