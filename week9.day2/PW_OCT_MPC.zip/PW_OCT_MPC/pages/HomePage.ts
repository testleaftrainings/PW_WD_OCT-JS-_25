import { Page } from '@playwright/test'

// Page Object Model for the Home page / top-level navigation
export class HomePage {
  constructor(private page: Page) {}

  // Click the 'Leads' link from the CRM landing page
  async clickLeads() {
    await this.page.click("a:has-text('Leads')")
  }

  // Click the 'Create Lead' link under Leads
  async clickCreateLead() {
    await this.page.click("a:has-text('Create Lead')")
  }

  // Click the 'Accounts' link from the CRM landing page
  async clickAccounts() {
    await this.page.click("a:has-text('Accounts')")
  }

  // Click the 'Create Account' link under Accounts
  async clickCreateAccount() {
    await this.page.click("a:has-text('Create Account')")
  }
}
